local shared = require 'SAMemory.shared'
shared.require 'CEntity'

-- Objects are type=3 entries in the current unified entity table.  No old
-- standalone CObject pool or full class layout is assumed here.
shared.ffi.cdef[[
    typedef CEntity CObject;
]]

return true
