local shared = require 'SAMemory.shared'
shared.require 'CPed'

-- Current player entities use the same confirmed CPed prefix.  This alias is
-- a separate ctype because LuaJIT FFI does not support typedef aliases with
-- the legacy inheritance syntax used by the original package.
shared.ffi.cdef[[
    typedef CPed CPlayerPed;
]]

return true
